package com.cg.exception;

@SuppressWarnings("serial")
public class CabApplicationException extends Exception{
	public CabApplicationException(String msg)
	{
		super(msg);
	}
}
