package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.DonorBean;
import com.cg.exception.CabApplicationException;
import com.cg.util.CabAppDBConnection;

public class CabRequestDAO implements IDonorDao{
	Logger logger=Logger.getRootLogger();
	public CabRequestDAO() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	StringBuilder s2=new StringBuilder("");
	DonorBean bean=null;
	
	@Override
	public int addCabRequestDetails(DonorBean cabRequest) throws CabApplicationException {
		Connection con;
		String requestId=null;
		
			con = CabAppDBConnection.getInstance().getConnection();
		
		PreparedStatement p=null;		
		ResultSet rs = null;
		String val=null;
		int queryresult=0;
		try {
			p=con.prepareStatement(IQueryMapper.insertDetailsQuery);
			
			p.setString(1, cabRequest.getCustomerName());
			p.setString(2,cabRequest.getPhoneNum());
			p.setString(3,cabRequest.getRequestStatus());
			p.setString(5,cabRequest.getAddress());	
			p.setString(6,cabRequest.getPincode());
			p.setString(4, cabRequest.getCabNumber());
			queryresult=p.executeUpdate();
			PreparedStatement p2= con.prepareStatement(IQueryMapper.seqQuery);
			rs=p2.executeQuery();
			if(rs.next())
			{
				val=rs.getString(1);
			}
			if(queryresult==0)
			{
				logger.error("Insertion failed ");
				throw new CabApplicationException("Inserting donor details failed ");
			}
			else
			{
				con.commit();
				logger.info("Donor details added successfully:");
				return Integer.parseInt(val);
			}
			return Integer.parseInt(val);
			
		}
		catch(SQLException e)
		{
			s2.append(e.getMessage());
			System.out.println(s2);
			logger.warn("Invalid details");
		}
		
	}

	@Override
	public DonorBean getRequestDetails(int requestId) throws SQLException {
		Connection connection=CabAppDBConnection.getInstance().getConnection();	
		PreparedStatement p=null;		
		ResultSet rs = null;
		String val=null;
		int queryresult=0;
		try
		{
			p=connection.prepareStatement(IQueryMapper.ViewCustDetailsQuery);
			p.setInt(1,requestId);
			rs=p.executeQuery();
			if(rs.next())
			{
				/*
				 * customerName,requestStatus,cabNumber,addressOfPickup
				 */
				bean= new DonorBean();
				bean.setCustomerName(rs.getString(1));
				bean.setRequestStatus(rs.getString(2));
				//bean.setPincode(rs.getString(1));
				bean.setCabNumber(rs.getString(3));
				bean.setAddress(rs.getString(4));
				
			}
			if(bean!=null)
			{
				logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Record Not Found");
				return null;
			}
			
		}catch(SQLException e)
		{
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		 finally
		{
			try 
			{
				rs.close();
				p.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CabApplicationException("Error in closing db connection");

		 
		
	}

	
}
